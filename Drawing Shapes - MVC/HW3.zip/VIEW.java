/**
 * a VIEW interface 
 * ontain the minimum specification needed for the DrawingBoard 
 * to be able to notify any viewer that the state has changed
 * @author Duong H Chau
 * @version HW3
 */ 
public interface VIEW{
  public void listChanged();
  
}